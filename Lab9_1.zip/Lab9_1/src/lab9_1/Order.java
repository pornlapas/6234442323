/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9_1;
import java.util.ArrayList;
/**
 *
 * @author Administrator
 */
public class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p;
public Order(Customer c) {
    this.c = c;
    p = new ArrayList<Pizza>();
}
public void addPizza(Pizza pizza) {
    p.add(pizza);
}
public String getOrderDetail() {
    String details = "";
    int totalPiece = 0;
    details += "Order id : "+cntOrder+"\n"+c.getName()+" tel : "+c.getTel()+"\n";
    if (c instanceof Customer) {
        cntOrder += 1;
        }
    else if (c instanceof GoldCustomer) {
        GoldCustomer c2 = (GoldCustomer) c;
        cntOrder += 1;
        details += " discount : "+c2.getDiscount();
        }
    for (Pizza pizza : p) {
            if (pizza instanceof PizzaSpecial) {
                totalPiece += 1;
                PizzaSpecial pspecial = (PizzaSpecial) pizza;
                details += pspecial.getName()+" price : "+pspecial.getPrice()+" special : "+pspecial.getSpecial()+"\n";
                }
            else {
                totalPiece += 1;
                details += pizza.getName() + " price : " + pizza.getPrice() + "\n";
                }
    }
    details += "Total pieces : "+totalPiece+"\nTotal cost : "+calculatePayment();
    return details;
}
public double calculatePayment() {
    double payment = 0;
        if (c instanceof GoldCustomer) {
            GoldCustomer c2 = (GoldCustomer) c;
            for (Pizza pspecial : p) {
                payment += pspecial.getPrice()-(pspecial.getPrice()*c2.getDiscount()*0.01);
            }
        }
        else {
            for (Pizza pizza : p) {
                payment += pizza.getPrice();
            }
        }
        return payment;
    }
}