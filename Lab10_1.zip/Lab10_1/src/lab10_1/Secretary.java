/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;
/**
 *
 * @author Administrator
 */
public class Secretary extends Employee implements Evaluation {
    private int typingSpeed;
    private int score;
    private int[] arrayScore;
public Secretary(String name, int salary, int[] arrayScore, int typingSpeed) {
    super(name,salary);
    this.typingSpeed = typingSpeed;
    this.arrayScore = arrayScore;
}
@Override
public double evaluate() {
   double sumScore = 0;
   for (int sc : arrayScore) {
       for (int i=0; i <= arrayScore.length-1; i++) {
           sumScore += arrayScore[i];
       }
   }
   return sumScore;
}
@Override
public char grade(double SumScore) {
    if (evaluate()<90) {
        return 'F';
    }
    else {
        super.setSalary(18000);
        return 'P';
    }
}
}
