/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_1;
/**
 *
 * @author Administrator
 */
public class Subject implements Evaluation {
    private String subjName;
    private int score;
    private int[] arrayScore;
public Subject(String subjName, int[] arrayScore) {
    this.subjName = subjName;
    this.arrayScore = arrayScore;
}
@Override
public double evaluate() {
   int sumScore = 0;
   double average = 0;
   for (int sc : arrayScore) {
       for (int i=0; i <= arrayScore.length-1; i++) {
           sumScore += arrayScore[i];
       }
       average += sumScore/arrayScore.length;
   }
   return average;
}
@Override
public char grade(double average) {
    if (evaluate()<70) {
        return 'F';
    }
    else {
        return 'P';
    }
}
@Override
public String toString() {
    return subjName;
}
}
