          /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_2;
import java.util.Random;
import java.util.Scanner;

public class Game
{  private int comscore;
   private int userscore;

public void play()
{
   while (comscore-userscore<2&&userscore-comscore<2)
   {
   Random generator = new Random();
   
   System.out.print("Enter 0 for ROCK,1 for PAPER,2 for SCISSORS: ");
   Scanner sc = new Scanner(System.in);
   int user = sc.nextInt();
   int comrandom = generator.nextInt(3);
   
   if (user==0||user==1||user==2)
        switch (user) {
            case 0:
                System.out.println("You enter: ROCK");
                    switch (comrandom) 
                    {
                        case 0:
                          System.out.println("Computer: ROCK");
                          System.out.println("It's a tie.");
                          break;
                        case 1:
                          System.out.println("Computer: PAPER");
                          System.out.println("You lose!");
                          comscore+=1;
                          break;
                        case 2:
                          System.out.println("Computer: SCISSOR");
                          System.out.println("You win!");
                          userscore+=1;
                          break; 
                    }
                break;
            case 1:
                System.out.println("You enter: PAPER");
                    switch (comrandom) 
                    {
                        case 0:
                          System.out.println("Computer: ROCK");
                          System.out.println("You win!");
                          userscore+=1;
                          break;
                        case 1:
                          System.out.println("Computer: PAPER");
                          System.out.println("It's a tie.");
                          break;
                        case 2:
                          System.out.println("Computer: SCISSOR");
                          System.out.println("You lose!");
                          comscore+=1;
                          break; 
                    }
                break;
            case 2:
                System.out.println("You enter: SCISSOR");
                    switch (comrandom) 
                    {
                        case 0:
                          System.out.println("Computer: ROCK");
                          System.out.println("You lose!");
                          comscore+=1;
                          break;
                        case 1:
                          System.out.println("Computer: PAPER");
                          System.out.println("You win!");
                          userscore+=1;
                          break;
                        case 2:
                          System.out.println("Computer: SCISSOR");
                          System.out.println("It's a tie.");
                          break; 
                    }
                break;
            default:
                break;
        }
   else
       System.out.println("Enter 0 for ROCK,1 for PAPER,2 for SCISSORS: ");
       
    }
    if (comscore>userscore) {
      System.out.println("Too bad! You lose.");
    }
    else if (comscore<userscore) {
      System.out.println("Congrats! You win.");
    }
    System.out.println("User score: "+Integer.toString(userscore));
    System.out.println("Computer score: "+Integer.toString(comscore));
  }
}