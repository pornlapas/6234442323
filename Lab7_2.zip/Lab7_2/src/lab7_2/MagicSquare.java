/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_2;

/**
 *
 * @author Administrator
 */
public class MagicSquare
{
    private final int[][] square;
    private final int n;
    int columns;
    int rows;
    
    public MagicSquare(int n)
    {
        this.n = n;
        square = new int[n][n];
        rows = n-1;
        columns = n/2;
        for(int num = 1; num <= n*n;)
        {
            if (rows == n && columns == n)
            {
                rows -= 2;
                columns--;
            }
            else
            {
                if(rows == n)
                {
                    rows = 0;
                }
                if(columns == n)
                {
                    columns = 0;
                }
            }
            
            if(square[rows][columns]!= 0)
                {
                rows -= 2;
                columns--;
                continue;
                }
            
            else{
                    square[rows][columns] = num++;
            }
            
            rows++; columns++; 
            } 
    }
@Override
    public String toString()
    {
      String x = "";
      for (int i = 0; i < n; i++) 
      {
            for (int j = 0; j < n; j++) 
            {
                x = x + square[i][j] + "\t";
            }
            x = x + "\n";
      }
      return x;
    }
}
