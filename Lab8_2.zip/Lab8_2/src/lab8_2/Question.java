/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;

/**
 *
 * @author Administrator
 */
public class Question {
    private String text;
    private String answer;
public Question(String text) {
    this.text = text;
}
public void setText(String newText) {
    this.text = newText;
}
public String getText() {
    return text;
}
public void setAnswer(String newAns) {
    this.answer = newAns;
}
public String getAnswer() {
    return answer;
}
public boolean checkAnswer(String response) {
    boolean check = answer.equals(response);
    return check;
}
public void display() {
    System.out.println(text);   
}
}