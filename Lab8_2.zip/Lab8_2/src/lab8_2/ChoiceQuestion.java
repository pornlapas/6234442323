/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;
import java.util.ArrayList;

/**
 *
 * @author Administrator
 */
public class ChoiceQuestion extends Question {
    ArrayList<String> choices = new ArrayList<>();
    private boolean check;
    public ChoiceQuestion() {
        super(null);
    }
    public ChoiceQuestion(String text) {
        super(text);
    }
    public void addChoice(String choice,boolean correct) {
        choices.add(choice);
        if (correct==true) {
            this.setAnswer(choice);
        }
    }
    @Override
    public void display() {
        System.out.println(super.getText());
        for (int i=0; i<=choices.size()-1; i++) {
            System.out.print(i+1);
            System.out.println(": "+choices.get(i));
        }
    }
    @Override
    public boolean checkAnswer(String response) {
        int intResponse = Integer.parseInt(response);
        check = intResponse==choices.indexOf(super.getAnswer())+1;
        return check;
    }
}
