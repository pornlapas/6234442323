/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_2;
/**
 *
 * @author Administrator
 */
public class NumericQuestion extends Question {
    public NumericQuestion() {
        super(null);
    }
    public NumericQuestion(String text) {
        super(text);
    }
    @Override
    public boolean checkAnswer(String response) {
        double diff = java.lang.Math.abs(Double.parseDouble(super.getAnswer())-Double.parseDouble(response));
        boolean check = diff<0.01;
        return check;
    }
}
