/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

/**
 *
 * @author Administrator
 */
public class BusTester {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bus arr[] = new Bus[2];
        arr[0] = new Hybrid(45,1.2,600,150,1);
        arr[1] = new CNGBus(50,1,200,2);
           for (Bus bus : arr) {
              if (bus instanceof Hybrid) {
                  Hybrid hybridBus = (Hybrid) bus;
                  System.out.println("ID: "+hybridBus.getID()+"\nEmission Tier: "+hybridBus.getEmissionTier()+"\nAccel: "+hybridBus.getAccel());
              }
              else if (bus instanceof CNGBus) {
                  CNGBus cng = (CNGBus) bus;
                  System.out.println("ID: "+cng.getID()+"\nEmission Tier: "+cng.getEmissionTier()+"\nAccel: "+cng.getAccel());
              }
           }
    }
    
}
