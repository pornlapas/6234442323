/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_2;

/**
 *
 * @author Administrator
 */
public class DigitExtractor {
    private int number;

public DigitExtractor(int num)
{
    number = num;
}
public int nextDigit()
{
    final int n = number%10;
    number = number/10;
    return n;
}
}
