/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author Administrator
 */
public class TimeInterval {
    private final String timestart;
    private final String timeend;
            
public TimeInterval(String start,String end)
{
    timestart = start;
    timeend = end;
}
public int getMinutes()
{
    int startminute = Integer.parseInt(timestart.substring(2));
    int endminute = Integer.parseInt(timeend.substring(2));
    int diffminute = Math.abs(endminute-startminute);
    return diffminute;
}
public int getHours()
{
    int starthour = Integer.parseInt(timestart.substring(0,2));
    int endhour = Integer.parseInt(timeend.substring(0,2));
    int diffhour = Math.abs(endhour-starthour);
    return diffhour;
}
}
