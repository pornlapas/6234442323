/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_3;

/**
 *
 * @author Administrator
 */
public class TimeInterval {
    private final int timeStart;
    private final int timeEnd;
    private final int tStart;
    private final int tEnd;
    private final int tStart1;
    private final int tEnd1;
    private final int diffMin;
            
public TimeInterval(int start,int end)
{
    timeStart = start;
    timeEnd = end;
    tStart =(timeStart/100)*60;
    tEnd = (timeEnd/100)*60;
    tStart1 = timeStart%100;
    tEnd1 = timeEnd%100;
    diffMin = (tEnd+tEnd1)-(tStart+tStart1);
}
public int getHours()
{
    int hour = diffMin/60;
    return hour;
}
public int getMinutes()
{
    int minute = diffMin%60;
    return minute;
}
}
