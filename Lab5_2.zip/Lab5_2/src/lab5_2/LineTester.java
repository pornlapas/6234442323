/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab5_2;

/**
 *
 * @author Administrator
 */
public class LineTester {
    public static void main(String[] args)
    {
        Line l11 = new Line(3,5);
        Line l12 = new Line(5);
        System.out.println("Are the two lines equals?: "+l11.equals(l12));
        System.out.println("Are the two lines parallel?: "+l11.isParallel(l12));
        System.out.println("Are the two lines intersect?: "+l11.isIntersect(l12));
        if(l11.isIntersect(l12)) {
             System.out.println("Point of intersection: "+String.format("%.2f",l11.getIntersectionPoint(l12).x)+","+String.format("%.2f",l11.getIntersectionPoint(l12).y));
    }
    }
}
