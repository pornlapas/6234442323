/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;
import java.util.ArrayList;
/**
 *
 * @author Administrator
 */
public class MusicBox implements SimpleQueue {
      ArrayList<String> musicArray = new ArrayList<>();
      
      public MusicBox() {
          
      }
      
      @Override
      public void enqueue(Object o) {
          String song = (String) o;
          musicArray.add(song);
          System.out.println(song+" is added in queue.");
      }
      @Override
      public void dequeue() {
          System.out.println("Now playing "+musicArray.get(0));
          musicArray.remove(0);
      }
}
