/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_1;
import java.util.ArrayList;
/**
 *
 * @author Administrator
 */
public class SelfCheckOut implements SimpleQueue {
    ArrayList<Product> arrayItem = new ArrayList<>();
    private double total;
    
    public SelfCheckOut() {
        total = 0;
    }
    
      @Override
      public void enqueue(Object o) {
          Product item = (Product) o;
          arrayItem.add(item);
          System.out.println(item.getName()+" is added in queue.");
      }
      @Override
      public void dequeue() {
          total += arrayItem.get(0).getPrice();
          arrayItem.remove(0);
      }
      public double getAmount() {
          return total;
      }
}
