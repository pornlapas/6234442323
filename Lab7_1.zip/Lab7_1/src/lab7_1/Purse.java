/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;
import java.util.ArrayList;

/**
 *
 * @author usci
 */
public class Purse {
  ArrayList<String> wallet = new ArrayList<>();
  ArrayList<String> walletReverse = new ArrayList<>();
  private String coinName;
  private String walletStr;
  
public void addCoin(String coinName)
{
    wallet.add(coinName);
}
  @Override
  public String toString()
{
    walletStr = "Purse"+wallet;
    return walletStr;
}
public ArrayList<String> reverse()
{
    int i = wallet.size()-1;
    while (i>=0)
    {
        walletReverse.add(wallet.get(i));
        i-=1;
    }
    return walletReverse;
}
public void transfer(Purse other)
{
    while (wallet.size() > 0)
        {
            other.wallet.add(wallet.get(0));
            wallet.remove(0);
        }
}
public boolean sameContents(Purse other)
{
    return this.wallet.equals(other.wallet);
}
public boolean sameCoins(Purse other)
{
    boolean same = false;
        for (int i =0; i<=this.wallet.size()-1; i++)
        {
            for (int n=0; n<=other.wallet.size()-1; n++)
            {
                same = this.wallet.get(i).equals(other.wallet.get(n)) ; 
                if(same==true) break;
            }
            if(same==false) break;
        }return same;
}

}