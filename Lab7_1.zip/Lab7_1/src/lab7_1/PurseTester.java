/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab7_1;
import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class PurseTester {
   public static void main(String[] args)
   {
       Purse wallet = new Purse();
       System.out.print("Add some coin(Quarter,Dime,Nickel): "); //test addCoin
       Scanner sc = new Scanner(System.in);
       String coinInput = sc.nextLine();
       String[] coinNames;
       coinNames = coinInput.split(",");
       int i=0;
       while (i<=(coinNames.length-1))
       {
           String coinName = coinNames[i];
           wallet.addCoin(coinName);
           i+=1;
       }   
       System.out.println("Your purse is "+wallet.toString()); //test toString
       System.out.println("Your reverse purse is Purse"+wallet.reverse());
       System.out.println("Create second Purse.");
       Purse wallet2 = new Purse();
       System.out.print("Add some coin(Quarter,Dime,Nickel): ");
       Scanner sc2 = new Scanner(System.in);
       String coinInput2 = sc2.nextLine();
       String[] coinNames2;
       coinNames2 = coinInput2.split(",");
       int n=0;
       while (n<=(coinNames2.length-1))
       {
           String coinName2 = coinNames2[n];
           wallet2.addCoin(coinName2);
           n+=1;
       } 
       System.out.println("Are both Purse has same context?: "+wallet.sameContents(wallet2)); //test  sameContents
       System.out.println("Are both Purse has same coins?: " + wallet.sameCoins(wallet2)); //test  sameCoins
       System.out.println("Transfer from purse to second purse.");
       wallet.transfer(wallet2); //test transfer
       System.out.println("first purse: purse"+wallet);
       System.out.println("second purse: purse"+wallet2);
       System.out.println("Are both Purse has same context?: "+wallet.sameContents(wallet2)); //test  sameContents
       System.out.println("Are both Purse has same coins?: " + wallet.sameCoins(wallet2)); //test  sameCoins
   }
}
