/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab6_3;

/**
 *
 * @author Administrator
 */
public class CityGridTester {
 public static void main(String[] args)
 {
    CityGrid city = new CityGrid(10);
        int i = 0,maxStep=0,totalStep=0;
        while(i<10000)
        {
            int step=0;
            while(step<1000 && city.isInCity())
            {
                city.walk();
                step++;
            }
            totalStep=totalStep+step;
            if(step>maxStep)
            {
                maxStep=step;
            }
            city.reset();
            i++;
        }
    double avStep = totalStep*0.0001;
    System.out.println("Average number of steps that a person can take and is still in the city: "+String.format("%.2f",avStep));
    System.out.println("Maximum number of steps that a person can take and is still in the city: "+maxStep);
 }   
}
