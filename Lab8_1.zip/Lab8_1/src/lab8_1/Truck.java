/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;

/**
 *
 * @author Administrator
 */
public class Truck extends Car{
    private final int M_weight;
    private final int weight;
    public Truck(int g, int eff,int max,int w) {
        super(g, eff);
        M_weight = max;
        if(M_weight>w)
        {
            this.weight = w;
        }
        else
        {
            this.weight = max;
        }
    }
    @Override
    public void drive(double distance) {
        double usedGas;
        if (weight<1)
        {
            usedGas = distance/efficiency;
            if (usedGas>gas) {
                System.out.println("You cannot drive too far, please add gas.");
            }
            else {
                gas = gas-usedGas;
            }
        }
        else if (weight<=10)
        {
            usedGas = (distance/efficiency)+(distance/efficiency)*(0.1);
            if (usedGas>gas) {
                System.out.println("You cannot drive too far, please add gas.");
            }
            else {
                gas = gas-usedGas;
            }
        }
        else if (weight<=20)
        {
            usedGas = (distance/efficiency)+(distance/efficiency)*(0.2);
            if (usedGas>gas) {
                System.out.println("You cannot drive too far, please add gas.");
            }
            else {
                gas = gas-usedGas;
            }
        }
        else
        {
            usedGas = (distance/efficiency)+(distance/efficiency)*(0.3);
            if (usedGas>gas) {
                System.out.println("You cannot drive too far, please add gas.");
            }
            else {
                gas = gas-usedGas;
            }
        }
    }
}
