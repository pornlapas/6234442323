/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8_1;
/**
 *
 * @author Administrator
 */
public class Car {
   public double gas;
   final int efficiency;
public Car(int g,int eff) {
    gas = g;
    efficiency = eff;
}
public void drive(double distance) {
    if (distance/efficiency > gas)
    {
        System.out.println("You cannot drive too far, please add gas.");
    }
    else if (distance/efficiency <= gas)
    {
        gas = (int)(gas-(distance/efficiency));
    }
}
public void setGas(double amount) {
    gas = amount;
}
public double getGas() {
    return gas;
}
public double getEfficiency() {
    return efficiency;
}
public void addGas(double amount) {
    gas = gas+amount;
}
}
