/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_1;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
/**
 *
 * @author Administrator
 */
public class SequentialTextFileTester {
    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        PrintWriter output = new PrintWriter("output.txt");
        int characters = 0;
        int lineNumber = 0;
        int words = 0;
        boolean nextLoop = true;
        while (nextLoop) {
            String str = input.nextLine();
            if (!str.equals("quit")) {
                output.println(str);
                lineNumber++;
                characters += str.length();
                String[] message = str.split(" ");
                words += message.length;
            }
            else {
                nextLoop = false;
            }
        }
        input.close();
        output.close();
        System.out.println("Total characters: "+characters);
        System.out.println("Total words: "+words);
        System.out.println("Total lines: "+lineNumber);
    } 
}
