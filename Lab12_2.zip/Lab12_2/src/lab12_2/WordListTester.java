/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Administrator
 */
public class WordListTester {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input;
        ArrayList<String> arrayFile = new ArrayList<>();
        File file = new File("wordlist.txt");
        try {
            input = new Scanner(file);
            while(input.hasNextLine()) {
                arrayFile.add(input.nextLine());
            }
        }
        catch (FileNotFoundException e) {
            System.out.println(e);
        }
        System.out.print("Enter a sentence: ");
        input = new Scanner(System.in);
        String str = input.nextLine();
        String[] messageArray = str.split(" ");
        System.out.print("Words not contained: ");
        int cnt = 0;
        for (String word : messageArray) {
            if (arrayFile.indexOf(word) < 0) {
                System.out.println(word);
                cnt++;
            }
        }
        if (cnt <= 0) {
                System.out.println("N/A");
        }
    } 
}
