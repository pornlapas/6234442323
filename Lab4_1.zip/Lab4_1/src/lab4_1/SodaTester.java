/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab4_1;

import java.util.Scanner;

/**
 *
 * @author usci
 */
public class SodaTester {
    public static void main(String[] args)
    {
    System.out.print("Enter height : ");
    Scanner height = new Scanner(System.in);
    double h = height.nextDouble();
    System.out.print("Enter diameter : ");
    Scanner diameter = new Scanner(System.in);
    double d = diameter.nextDouble();
    SodaCan c = new SodaCan(h,d);
    System.out.println("Vloume : "+String.format("%.2f",c.getVolume()));
    System.out.println("Surface area : "+String.format("%.2f",c.getSurfaceArea()));
    }
}
